module.exports = {
    DATABASE_URL:  process.env.DATABASE_URL,
    DATABASE_PORT: process.env.DATABASE_PORT
}



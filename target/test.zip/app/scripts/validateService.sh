#!/bin/bash
cd /home/ubuntu/app && sudo pm2 status index.js

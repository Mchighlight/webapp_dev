#!/bin/bash
aws s3 cp s3://codedeploy.mchighlight/app.zip /home/ubuntu/app.zip
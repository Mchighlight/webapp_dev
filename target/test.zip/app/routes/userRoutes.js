const express = require('express') ;
const router = express.Router();
const { createUser, signIn, updateUser } = require('../controllers/usersController');
const basicAuth = require('../middlewares/verifyBasicAuth');

// users Routes

router.post('/signu', createUser);
router.get('/signin', basicAuth, signIn);
router.put('/update', basicAuth, updateUser);

module.exports = router;
